/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mode.bean;

/**
 *
 * @author serpa
 */
public class Produtos {
    
    private int codigo;
    private String Nome;
    private String NomeReduzido;
    private String Fabricante;
    private String Familia;
    private String ClassABC;
    private String Tipo;
    private String Desconto;
    private String Situacao;
    private String CodigoBarras;
    private String Referencia;
    private String ReferenciaOriginal;
    private String TipoProducao;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getNomeReduzido() {
        return NomeReduzido;
    }

    public void setNomeReduzido(String NomeReduzido) {
        this.NomeReduzido = NomeReduzido;
    }

    public String getFabricante() {
        return Fabricante;
    }

    public void setFabricante(String Fabricante) {
        this.Fabricante = Fabricante;
    }

    public String getFamilia() {
        return Familia;
    }

    public void setFamilia(String Familia) {
        this.Familia = Familia;
    }

    public String getClassABC() {
        return ClassABC;
    }

    public void setClassABC(String ClassABC) {
        this.ClassABC = ClassABC;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public String getDesconto() {
        return Desconto;
    }

    public void setDesconto(String Desconto) {
        this.Desconto = Desconto;
    }

    public String getSituacao() {
        return Situacao;
    }

    public void setSituacao(String Situacao) {
        this.Situacao = Situacao;
    }

    public String getCodigoBarras() {
        return CodigoBarras;
    }

    public void setCodigoBarras(String CodigoBarras) {
        this.CodigoBarras = CodigoBarras;
    }

    public String getReferencia() {
        return Referencia;
    }

    public void setReferencia(String Referencia) {
        this.Referencia = Referencia;
    }

    public String getReferenciaOriginal() {
        return ReferenciaOriginal;
    }

    public void setReferenciaOriginal(String ReferenciaOriginal) {
        this.ReferenciaOriginal = ReferenciaOriginal;
    }

    public String getTipoProducao() {
        return TipoProducao;
    }

    public void setTipoProducao(String TipoProducao) {
        this.TipoProducao = TipoProducao;
    }
    
    
    
    
}
